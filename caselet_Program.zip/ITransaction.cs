﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank
{
    interface ITransaction
    {
         void transferAmount();
    }
    interface IROI
    {
        void GetRateOfInterest(long a);
    }
}
