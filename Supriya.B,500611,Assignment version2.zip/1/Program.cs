﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the amount in dollars");
            int currency=int.Parse(Console.ReadLine());
            Console.WriteLine($"The amount in indian rupees is {currency*65.48}");
            Console.WriteLine($"The amount in british pounds is {currency*0.81}");
            Console.ReadLine();


        }
    }
}
