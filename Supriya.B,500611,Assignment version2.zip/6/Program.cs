﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment6
{
    class Program
    {
        static void Main(string[] args)
        {
            double principal = 0;
            double time = 0;
            Console.WriteLine("Enter the principal amount");
            try
            {
                 principal = getDouble();
            }
            catch (FormatException e)
            {

                Console.WriteLine(e.Message);
            }
            Console.WriteLine("Enter the time in terms of years");
            try
            {
               time = getDouble();
            }
            catch (FormatException e)
            {

                Console.WriteLine(e.Message);
            }
            int rate;
            if (time <= 1)
                rate = 2;
            else if (time > 1 & time <= 2)
                rate = 3;
            else rate = 4;
            double simplerate = principal * time * rate / 100;
            double amount = principal + simplerate;
            Console.WriteLine($"The Principal amount is {principal} and rate of interest is {rate}% for a period of {time} years amounts to total amount {amount} and with interest amount {simplerate}");
            Console.ReadLine();
        }
        public static double getDouble()
        {
            double choice;
            if (double.TryParse(Console.ReadLine(), out choice))
                return choice;
            else
                throw new FormatException();
        }
    }
}
