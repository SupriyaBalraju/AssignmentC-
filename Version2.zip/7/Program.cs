﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeanMedianMode
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;
            float median = 0;
            Console.WriteLine("Enter the total number of values");
            int n = int.Parse(Console.ReadLine());
            if (n < 3)
            {
                Console.WriteLine("total numbers should be more than 2");
            }
            int[] arr = new int[n];
            Console.WriteLine("Enter the values");

            for (int i = 0; i < n; i++)
            {
                try
                {
                    arr[i] = getint();
                }
                catch (FormatException e)
                {

                    Console.WriteLine(e.Message);
                }
            }
            Console.WriteLine("The value taken are");
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine(arr[i]);
            }
            for (int i = 0; i < n; i++)
            {

                sum = sum + arr[i];
            }
            float mean = 0;
            mean = (float)sum / n;
            Console.WriteLine($"The Mean is {mean}");
            if (n % 2 == 1)
            {
                median = arr[n / 2];
                Console.WriteLine($"The Median is {median}");
            }
            else
            {
                for (int i = 0; i < n; i++)
                {
                    for (int j = i + 1; j < n; j++)
                    {
                        if (arr[i] > arr[j])
                        {
                            int temp = arr[i];
                            arr[i] = arr[j];
                            arr[j] = temp;
                        }

                    }
                }
                Console.WriteLine("The value after sorting");
                for (int i = 0; i < n; i++)
                {
                    Console.WriteLine(arr[i]);
                }

                median = (float)(arr[n / 2] + arr[(n / 2) - 1]) / 2;
                Console.WriteLine($"The Median is {median}");

            }
            Console.ReadLine();
        }
        public static int getint()
        {
            int choice;
            if (int.TryParse(Console.ReadLine(), out choice))
                return choice;
            else
                throw new FormatException();
        }
    }
}
