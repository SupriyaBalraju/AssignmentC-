﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment8
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            try
            {
                i = getint();
            }
            catch (FormatException e)
            {

                Console.WriteLine(e.Message);
            }
            Testmethod(i);
            Console.ReadLine();
        }
        static bool IsPrime(int x)
        {
            for (int i = 2; i < x; i++)
            {
                if (x % i == 0)
                 return false;
            }
            return true;
        }
        static void Testmethod(int y)
        {
            if(IsPrime(y))
                Console.WriteLine("The test is pass and given number is prime number");
            else
                Console.WriteLine("The test is fail and given number is not prime");
        }
        public static int getint()
        {
            int choice;
            if (int.TryParse(Console.ReadLine(), out choice))
                return choice;
            else
                throw new FormatException();
        }
    }
}
