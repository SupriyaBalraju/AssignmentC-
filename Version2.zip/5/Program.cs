﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4
{
    class Program
    {
        static void Main(string[] args)
        {
            int range = 0;
            Console.WriteLine("Enter the range");
            try
            {
                range = getint();
            }
            catch (FormatException e)
            {

                Console.WriteLine(e.Message);
            }
            int[] fibo =new int[range];
            fibo[0] = 0;fibo[1] = 1;
            for (int i = 2; i<fibo.Length; i++)
            {
                fibo[i] = fibo[i - 1] + fibo[i - 2];
                Console.WriteLine(fibo[i]);
            }
            Console.ReadLine();
        }
        public static int getint()
        {
            int choice;
            if (int.TryParse(Console.ReadLine(), out choice))
                return choice;
            else
                throw new FormatException();
        }
    }
}
