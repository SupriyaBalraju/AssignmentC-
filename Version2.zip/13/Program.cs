﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment14
{
    abstract class Shapes
    {
        public static double  length;
        public static double width;
        public abstract void Area();
    }
    class Triangle : Shapes
    {
        public override void Area()
        {
            double area = (length * width) / 2;
            Console.WriteLine("area is " + area);
        }
    }
    class Rectangle : Shapes
    {
        public override void Area()
        {
            double area = length * width;
            Console.WriteLine("area is {0}"+ area);
        }
    }
    class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("1.Triangle \n 2.Rectangle");
            int choice;
            if ((int.TryParse(Console.ReadLine(), out choice)) && choice < 2)
                {
                Console.WriteLine("Enter length");
                Shapes.length = double.Parse(Console.ReadLine());
                Console.WriteLine("Enter breadth");
                Shapes.width = double.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1: Triangle tri = new Triangle();
                        tri.Area();
                        break;
                    case 2:
                        Rectangle rec = new Rectangle();
                        rec.Area();
                        break;
                }
                Console.ReadLine();
            }
        }
    }
}
