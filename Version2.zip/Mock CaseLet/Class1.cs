﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingSystem
{
    public class InvalidOption : Exception
    {
        string s;
       public  InvalidOption(string message)
        {
            s = message;
        }
        public string  getmessage()
        {
            return s;
        }
    }
}
