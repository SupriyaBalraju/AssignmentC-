﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingSystem
{
    interface ITransaction
    {
         string fromAccount { get; set; }
        string toAccount { get; set; }
        void TransferAmount();
    }
}
