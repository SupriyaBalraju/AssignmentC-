﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingSystem
{
     abstract class Account
    {
        public readonly string accno;
        
        public string username { get; set; }
        public string phno { get; set; }
        public int balance { get; set; }
        public Account()
        {
            accno = openAccount();
        }
        abstract public void deposit();
        abstract public void withdrawl();
        public string openAccount()
        {
            Random r1 = new Random();
            char[] a;
            Console.WriteLine("Enter the name");
                username = Console.ReadLine();
                a = username.ToCharArray();
                for (int i = 0; i < a.Length; i++)
                {
                    if (!System.Char.IsLetter(a[i]))
                        throw new InvalidOption("Please enter only alphabets");
                } 
            Console.WriteLine("Enter the phone number");
            phno = Console.ReadLine();
            if (phno.Length < 10 || phno.Length > 10)
                throw new InvalidOption("Please enter valid 10 digit number");
             a = phno.ToCharArray();
            for (int i = 0; i < a.Length; i++)
            {
                if (!System.Char.IsDigit(a[i]))
                {
                    throw new InvalidOption("Please Enter only numbers");
                }
            }
            Console.WriteLine("Please deposit a minimum balance of 1000 to open an account");
            int b = int.Parse(Console.ReadLine());
            if (b < 1000)
                throw new InvalidOption("Enter 1000 rupees to create account");
            this.balance = b;
            string acc = "";
            for (int i = 1; i < 13; i++)
            {
                acc += r1.Next(0, 9).ToString();
            }
            Console.WriteLine($"your account is created and the account number is {acc}");
            Console.ReadLine();
                return acc;
        }
        public abstract void removeAcc();
        public void editAcc()
        {
            Console.WriteLine("Enter 1 for changing name and 2 for changing number");
            int choice = int.Parse(Console.ReadLine());
            switch(choice)
            {
                case 1:this.username = Console.ReadLine();
                    break;
                case 2:this.phno = Console.ReadLine();
                    break;
            }
        }
        public void miniStatement()
        {
            Console.WriteLine($"Your account number is {this.accno} and balance is {this.balance}");
        }
    }
}
