﻿namespace myDemoLibrary
{
    internal class Product
    {
    }
}