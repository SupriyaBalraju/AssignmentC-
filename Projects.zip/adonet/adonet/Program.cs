﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace adonet
{
    class Program
    {
        static string constring = Properties.Settings.Default.conString;
        static void Main(string[] args)
        {

            using (SqlConnection con = new SqlConnection(constring))
            {
                string cmdString = @"SELECT * FROM Employees; SELECT * FROM Customers";
                con.Open();
                Console.WriteLine($"state ={con.State}");
                using (SqlCommand cmd = new SqlCommand(cmdString,con))
                {
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    

                    foreach(DataRow dr in ds.Tables[0].Rows)
                    {
                        Console.WriteLine($"{ dr["FirstName"]} {dr["LastName"]} {dr["Country"]}");
                        Console.WriteLine($"");
                    }



                }


                Console.Read();
            }
        }
    }
}
