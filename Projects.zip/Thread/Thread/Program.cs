﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;



namespace Threading
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("main method started");

            Thread th = new Thread(new ThreadStart(longMethod));
            th.Start();

            for(int i=0;i<10;i++)
            {
                Console.WriteLine($"imside main method-executing{i}");
                Thread.Sleep(3000);

                Program.longMethod();
            }
            Console.WriteLine("main method ended");
            Console.Read();
        }

        public static void longMethod()
        {
            Console.WriteLine("inside long methodd");
        }
    }
}
