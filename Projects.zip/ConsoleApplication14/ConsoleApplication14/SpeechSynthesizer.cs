﻿namespace ADO1
{
    internal class SpeechSynthesizer
    {
    }
}