﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using vehicle_dealer;



namespace vehicle_dealer
{
    public class Model : vehicle_dealer.Vehicle
    {

        public string model;
        public double price;
        public Boolean instock;

        public Model() { }
        public Model(int i, string mod)
        {
            this.id = i;
            this.model = mod;

        }
        public Model(string ty, string na, int i, string mod, double pr)
        {
            this.type = type;
            this.name = na;
            this.id = i;
            this.model = mod;
            this.price = pr;
        }


        public override string ToString()
        {
            return "\t type\t" + type + "\tname\t" + name + "\tid\t" + id + "\tmodel\t" + model + "\tprice\t" + price;

        }
        public void addModel(List<Model> modelList)
        {
            Console.WriteLine("Enter vehicle type Like CAR ,VAN and STATIONWAGON ");
            type = Console.ReadLine();
            if (Regex.IsMatch(type, "[a-zA-Z]"))
            {
                Console.WriteLine("Please enter the vehicle type!!!!");
                Console.ReadLine();
            }
            Console.WriteLine("Enter Vehicle name");
            name = Console.ReadLine();
            if (Regex.IsMatch(name, @"^[a-zA-Z]+$"))
            {
                Console.WriteLine(name);
                Console.ReadLine();
            }
            Random ranid = new Random();
            id = ranid.Next(1000, 9999);
            Console.WriteLine("Vehicle Id is{0}", +id);
            Console.WriteLine("Enter name of model to be added");
            model = Console.ReadLine();
            if (Regex.IsMatch(model, @"^[a-zA-Z]+$"))
            {
                Console.WriteLine("No model name entered!");
                Console.ReadLine();
            }
            Console.WriteLine("Enter Price");
            price = Convert.ToDouble(Console.ReadLine());
            while (price < 0)
            {
                Console.WriteLine("Price cannot be negative");
                Console.WriteLine("Please enter positive price");
                price = Convert.ToInt32(Console.ReadLine());
            }
            modelList.Add(new Model(type, name, id, model, price));
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\tModel added successfully!!!");
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine(ToString());

        }
        class Modelprice : ApplicationException
        {

            public string price
            {
                get { return "There are no models to modify the price"; }
            }
        }
        public void modifyPrice(List<Model> modelList)
        {
            try
            {
                int flag = 0;
                Console.WriteLine("enter the vehicle id whose price is to be changed");
                int priceChangeid = Convert.ToInt32(Console.ReadLine());
                for (int i = 0; i < modelList.Count; i++)
                {
                    if (modelList[i].id == priceChangeid)
                    {
                        flag = 1;
                        Console.WriteLine("enter new price");
                        double priceChanheid = Convert.ToDouble(Console.ReadLine());
                        modelList[i].price = priceChanheid;
                        Console.WriteLine("price has been changed" + modelList[i].price);

                        break;

                    }
                }
                if (flag == 0)
                {
                    Console.ForegroundColor = ConsoleColor.DarkGreen;
                    Console.WriteLine("No id found!!!");
                    Console.ForegroundColor = ConsoleColor.Black;
                }
            }
            catch (Modelprice p)
            {
                Console.ForegroundColor = ConsoleColor.DarkMagenta;
                Console.WriteLine(p.price);
                Console.ForegroundColor = ConsoleColor.DarkBlue;
            }
        }



        class Modeldisplay : ApplicationException
        {

            public string Display
            {

                get
                {
                    return "There are no models to display";
                    

                }

            }


        }

        public void displayallModels(List<Model> modelList)
        {
            int count = 0;
            try
            {


                foreach (Model j in modelList)
                {
                    Console.WriteLine("{0},{1},{2}", j.id, j.model, j.price);
                    count++;
                }
                if (count == 0)
                {
                    throw (new Modeldisplay());
                }

            }


            catch (Modeldisplay e)
            {
                Console.ForegroundColor = ConsoleColor.DarkMagenta;
                Console.WriteLine(e.Display);
                Console.ForegroundColor = ConsoleColor.White;
            }


        }

        public void deleteModel(List<Model> modelList)
        {
            int j = 0, flag = 0;
            try
            {
                Console.WriteLine("Enter the modelid to be deleted");
                int deleteid = int.Parse(Console.ReadLine());
                modelList.RemoveAt(deleteid);
                Console.ForegroundColor = ConsoleColor.DarkGreen;
                Console.WriteLine("Model deleted successfully!!!");
                Console.ForegroundColor = ConsoleColor.White;

                foreach (Model x in modelList)
                {
                    Console.WriteLine("Enter the modelid to be deleted");
                    deleteid = int.Parse(Console.ReadLine());
                    if (x.id == deleteid)
                    {
                        flag = 1;
                        modelList.RemoveAt(j);
                        Console.ForegroundColor = ConsoleColor.DarkGreen;
                        Console.WriteLine("Model deleted successfully");
                        Console.ForegroundColor = ConsoleColor.White;
                        break;
                    }

                }
                j++;

                //if (flag == 0)
                //{
                //    throw (new deleteunderflow());
                //}

            }
            catch (Exception)
            {

            }

        }

        public void lowestPricedModel(List<Model> modelList)
        {
            double min = 600000;
            for (int i = 0; i < modelList.Count; i++)
            {
                if (modelList[i].price < min)
                {
                    min = modelList[i].price;
                }
            }

            Console.WriteLine("The lowest price is {0}", min);



        }

        public void modelsInAPriceRange(List<Model> modelList)
        {
            double lower, upper;
            Console.WriteLine("enter the lower price in the range");
            lower = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("enter the upper price in the range");
            upper = Convert.ToDouble(Console.ReadLine());
            int flag = 0;

            foreach (Model y in modelList)
            {
                if (y.price > lower && y.price < upper)
                {
                    flag = 1;
                    Console.WriteLine("The model details are");
                    Console.WriteLine("{0},{1},{2}", y.id, y.model, y.price);
                    break;

                }
            }
            if (flag == 0)
            {
                Console.WriteLine("No vehicles present in this range");
            }

        }



        public void display1model(List<Model> modelList)
        {
            int flag = 0;
            Console.WriteLine("enter the model no to be displayed");
            int i = Convert.ToInt32(Console.ReadLine());

            foreach (Model j in modelList)
            {
                if (j.id == i)
                {
                    flag = 1;
                    Console.WriteLine("the model details are");
                    Console.WriteLine("{0},{1},{2}", j.id, j.model, j.price);
                    break;
                }
            }


            if (flag == 0)
            {
                Console.WriteLine("the entered model no is invalid please try again");

            }


        }



        public void checkAvailable(List<Model> modelList)
        {
            int flag = 0;
            Console.WriteLine("enter the model number to be checked for availability");
            int i = Convert.ToInt32(Console.ReadLine());
            foreach (Model j in modelList)
            {
                if (j.id == i)
                {
                    flag = 1;
                    bool instock = true;
                    if (instock == true)
                    Console.WriteLine("________the given model is available__________\n");
                    Console.Read();

                }
            }
            if (flag == 0)
            {


                Console.WriteLine("________the given model is not available________\n");

            }

            Console.Read();
        }

        public void IcalculateVAT()
        {
            Console.WriteLine("Enter Price");
            price = Convert.ToDouble(Console.ReadLine());
            while (price < 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Error !!! Price cannot be negative, Please enter positive price ");
                Console.ForegroundColor = ConsoleColor.DarkBlue;
                IcalculateVAT();
                Console.Read();
            }
            while (price <= 10000)
            {
                Console.ForegroundColor = ConsoleColor.DarkCyan;
                Console.WriteLine("Please enter price above 10000");
                Console.ForegroundColor = ConsoleColor.DarkCyan;
                IcalculateVAT();
                Console.Read();
            }
            double vat = 4.5;
            vat = (4.5 * price) / 100;
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.WriteLine("The VAT is" + vat);
            Console.ForegroundColor = ConsoleColor.DarkCyan;
           
        }

        //public void exit()
        //{
        //   if(char==
        //}


        internal deleteunderflow d { get; set; }

    }
}
