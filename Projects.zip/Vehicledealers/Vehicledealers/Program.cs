﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace vehicle_dealer
{
    class Program
    {
        static void Main(string[] args)
        {
            Model obj = new Model();
            List<Model> modelList = new List<Model>
            {
                new Model {id= 1,model="Swift",price=650000,instock=true },
                new Model {id= 2,model="Civic",price=1300000,instock=true },
                new Model {id= 3,model="Accord",price=6500000,instock=true },
                new Model {id= 4,model="Audi A6",price=10000000,instock=true },
                new Model {id= 5,model="Jaguar",price=150000000,instock=true },
                new Model {id= 6,model="Ashokleyland45",price=6500000,instock=true },
                new Model {id= 7,model="PiaggioApe",price=1300000,instock=true },
                new Model {id= 8,model="Mahindra1",price=6500000,instock=true },
                new Model {id= 9,model="Goodsvan23",price=10000000,instock=true },
                new Model {id= 10,model="Mercedes123",price=150000000,instock=true },
                new Model {id= 11,model="Ashokleyland45",price=6500000,instock=true },
                new Model {id= 12,model="PiaggioApe123",price=1300000,instock=true },
                new Model {id= 13,model="Mahindra1345",price=6500000,instock=true },
                new Model {id= 14,model="Goodsvan236",price=10000000,instock=true },
                new Model {id= 15,model="Mercedes1236",price=150000000,instock=true },

            };

            while (true)
            {
                Console.ForegroundColor = ConsoleColor.DarkCyan;
                Console.WriteLine("\tWelcome to Mahindra 4 wheel Dealers !!!\n");
                Console.WriteLine("\t*****************************************\n");
                Console.ForegroundColor = ConsoleColor.DarkBlue;
                Console.WriteLine("\t Choose Your Choice:\n \t1.Add Model\n \t2.Delete Model\n \t3.Display All Models\n \t4.Modify Price\n \t5.Lowest Priced Model\n \t6.Models In A given price Range\n \t7.Display1 Model\n \t8.Check if a Model is Available\n \t9.Calculate VAT\n\t10.Exit\n");
                Console.WriteLine("\nEnter your choice");
                int ch = Convert.ToInt32(Console.ReadLine());

                switch (ch)
                {
                    case 1:
                        obj.addModel(modelList);
                        break;
                    case 2:
                        obj.deleteModel(modelList);
                        break;
                    case 3:
                        obj.displayallModels(modelList);
                        break;
                    case 4:
                        obj.modifyPrice(modelList);
                        break;
                    case 5:
                        obj.lowestPricedModel(modelList);
                        break;
                    case 6:
                        obj.modelsInAPriceRange(modelList);
                        break;
                    case 7:
                        obj.display1model(modelList);
                        break;

                    case 8:
                        obj.checkAvailable(modelList);
                        break;
                    case 9:
                        obj.IcalculateVAT();
                        break;
                    case 10:
                        //obj.exit();
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Please enter valid choice");
                        break;

                }
            }
        }
    }
}


