﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace currency_convertion
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Currency converter");
            Console.WriteLine("Enter the currency in $ :");
            var a = double.Parse(Console.ReadLine());
            var rupee = a * 65.8;
            Console.WriteLine("The value of " + a + "$ is " + rupee + " Rupees");
            var pound = a * 0.81;
            Console.WriteLine("The value of " + a + "$ is " + pound + " Pounds");
            Console.Read();
        }
    }
}
