﻿namespace isprime
{
    internal class boolean
    {
    }
}