﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO1
{
    class Program
    {
        static string conString = @"Server=INCHCMPC08939;Database=Northwind;trusted_connection=true;";

        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine(" ---- BEFORE MODIFICATION ----- ");
                //DisplayCount();
                DisplayData();

                InsertData();
                //UpdateData();
                DeleteData();

                Console.WriteLine(" ---- AFTER MODIFICATION ----- ");
                DisplayData();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.Read();
        }

        private static void DeleteData()
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();

                string updateString = @"DELETE FROM Employees WHERE EmployeeID = 12";
                using (SqlCommand cmd = new SqlCommand(updateString, con))
                {
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private static void UpdateData()
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();

                string updateString = @"UPDATE Employees SET FirstName = 'Jack' WHERE EmployeeID = 12";
                using (SqlCommand cmd = new SqlCommand(updateString, con))
                {
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private static void InsertData()
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                string selectString = @" SELECT * FROM EMPLOYEES";

                DataSet ds = new DataSet();
                SqlDataAdapter da = new SqlDataAdapter(selectString, con);
                SqlCommandBuilder scb = new SqlCommandBuilder(da);

                da.Fill(ds);

                foreach(DataRow dar in ds.Tables[0].Rows)
                {
                    if ((int)dar["EmployeeId"] == 7)
                        dar["FirstName"] = "BOB";
                }
                foreach (DataRow dar in ds.Tables[0].Rows)
                {
                    if ((int)dar["EmployeeId"] == 14)
                        dar.Delete();
                }

                DataRow dr = ds.Tables[0].NewRow();
                dr["FirstName"] = "Donald";
                dr["LastName"] = "Trump";
                DataTable dt = ds.Tables[0];
                dt.Rows.Add(dr);


                da.Update(ds);
            }
        }

        private static void DisplayData()
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();
                string selectAllString = @"SELECT * FROM EMPLOYEES";
                using (SqlCommand cmd = new SqlCommand(selectAllString, con))
                {
                    SqlDataReader rdr = cmd.ExecuteReader();
                    while (rdr.Read())
                    {
                        Console.WriteLine($"FirstName: {rdr["FirstName"]}  | LastName: {rdr["LastName"]}");
                    }
                }

            }
        }

        private static void DisplayCount()
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();
                string selectAllString = @"SELECT COUNT(*) FROM EMPLOYEES";
                using (SqlCommand cmd = new SqlCommand(selectAllString, con))
                {
                    int count = (int)cmd.ExecuteScalar();
                    Console.WriteLine($"Total no. of records = {count}");
                }
            }
        }

    }
}


