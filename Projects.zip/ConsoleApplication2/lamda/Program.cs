﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lamda
{
    class Program
    {
        delegate int MyDelegate(int i, int j);
        static void Main(string[] args)
        {
            MyDelegate del = (i, j) => i + j;
            var result = del(5, 7);
            Console.WriteLine(result);
            Console.WriteLine("---------------------------------------------------");
            MyDelegate del1 = (i, j) => i - j;
            var result1 = del1(5, 3);
            Console.WriteLine(result1);
            Console.WriteLine("---------------------------------------------------");
            MyDelegate del2 = (i, j) => i * j;
            var result2 = del2(5, 2);
            Console.WriteLine(result2);
            Console.WriteLine("---------------------------------------------------");
            MyDelegate del3 = (i, j) => i / j;
            var result3 = del3(5, 1);
            Console.WriteLine(result3);
            Console.Read();
        }
    }
}
