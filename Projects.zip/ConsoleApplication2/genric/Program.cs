﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace genric
{
    class Program
    {
        class person
        {
            public int id { get; set; }
            public string name { get; set; }

        }
        class employee:person
        {

        }
        class manager:person
        {
            manager(int id, string name)
            {

            }
        }
        static void Main(string[] args)
        {
            employee e = employee(5,"lee");
            sayhello(e);
        }
        public void sayhello<T>(T t)
        {
            Console.WriteLine(t.GetType());
            Console.WriteLine("hello world!!!");
        }
        }
    }

