﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace genericdelegate
{
    class Program
    {
        static void Main(string[] args)
        {
            //generic delegate
            Func<int, int, int> del = (i, j) => i * j;
            var result = del(5, 7);
            Console.WriteLine(result);
            Console.Read();
        }
    }

}
