﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Errormsgcolourchng
{
    class Program
    {


        static void Main(string[] args)
        {
            Console.WriteLine("Hello user!! Please Enter your no pointing your favorite colour");
            Console.WriteLine("0.BLACK");
            Console.WriteLine("1.DARK BLUE");
            Console.WriteLine("2.DARK GREEN");
            Console.WriteLine("3.DARK CYAN");
            Console.WriteLine("4.DARK RED");
            Console.WriteLine("5.DARK MAGENTA");
            Console.WriteLine("6.DARK YELLOW");
            Console.WriteLine("7.GRAY");
            Console.WriteLine("8.DARK GRAY");
            Console.WriteLine("9.BLUE");
            Console.WriteLine("10.GREEN");
            Console.WriteLine("11.CYAN");
            Console.WriteLine("12.RED");
            Console.WriteLine("13.MAGENTA");
            Console.WriteLine("14.YELLOW");
            int s= int.Parse(Console.ReadLine());
            switch (s)
            {
                case 0:
                   Console.ForegroundColor = ConsoleColor.Black;
                    Console.WriteLine("!!!!!! HAPPY !!!!!!!!");
                    break;
                case 1:
                    Console.ForegroundColor = ConsoleColor.DarkBlue;
                    Console.WriteLine("!!!!!! HAPPY !!!!!!!!");
                    break;
                case 2:
                   Console.ForegroundColor = ConsoleColor.DarkGreen;
                    Console.WriteLine("!!!!!! HAPPY !!!!!!!!");
                    break;
                case 3:
                    Console.ForegroundColor = ConsoleColor.DarkCyan;
                    Console.WriteLine("!!!!!! HAPPY !!!!!!!!");
                    break;
                case 4:
                    Console.ForegroundColor = ConsoleColor.DarkRed;
                    Console.WriteLine("!!!!!! HAPPY !!!!!!!!");
                    break;
                case 5:
                    Console.ForegroundColor = ConsoleColor.DarkMagenta;
                    Console.WriteLine("!!!!!! HAPPY !!!!!!!!");
                    break;
                case 6:
                    Console.ForegroundColor = ConsoleColor.DarkYellow;
                    Console.WriteLine("!!!!!! HAPPY !!!!!!!!");
                    break;
                case 7:
                   Console.ForegroundColor = ConsoleColor.Gray;
                    Console.WriteLine("!!!!!! HAPPY !!!!!!!!");
                    break;
                case 8:
                    Console.ForegroundColor = ConsoleColor.DarkGray;
                    Console.WriteLine("!!!!!! HAPPY !!!!!!!!");
                    break;
                case 9:
                   Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine("!!!!!! HAPPY !!!!!!!!");
                    break;
                case 10:
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("!!!!!! HAPPY !!!!!!!!");
                    break;
                case 11:
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("!!!!!! HAPPY !!!!!!!!");
                    break;
                case 12:
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("!!!!!! HAPPY !!!!!!!!");
                    break;
                case 13:
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("!!!!!! HAPPY !!!!!!!!");
                    break; 
                case 14:
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("hello error!!");
                   
                    break;
                    Console.ReadLine();
            }
            Console.WriteLine("hello error!!");
            Console.WriteLine("hello error!!");
            Console.WriteLine("hello error!!");
            Console.WriteLine("hello error!!");





            Console.ReadLine();

        }
    }
}
