﻿namespace collectionemp
{
    internal class Employee
    {
        System.Console.writeline
        internal object Name { get; set; }

        public object id { get; internal set; }
    }
}