﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace isprime
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number: ");
            int num = int.Parse(Console.ReadLine());
            IsPrime(num);
            Console.Read();
        }
        public static void IsPrime(int num1)
        {
            if (num1 == 0 || num1 == 1)
            {
                Console.WriteLine("The number " + num1 + " is not a Prime number ");
                Console.Read();
            }
            else
            {
                for (int a = 2; a <= num1 / 2; a++)
                {
                    if (num1 % a == 0)
                    {
                        Console.WriteLine(num1 + " is not prime number");
                        return;

                    }

                }
                Console.WriteLine(num1 + " is a prime number");
                Console.ReadLine();


            }
        }

    }
   




}
