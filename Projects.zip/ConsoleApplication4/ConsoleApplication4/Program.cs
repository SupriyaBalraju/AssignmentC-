﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(" Welcome to employee management system!!");
            Console.WriteLine("enter ID");
            int id = int.Parse(Console.ReadLine());
            Console.WriteLine("enter FIRST NAME");
            string FN = Console.ReadLine();
            Console.WriteLine("enter LAST NAME");
            string LN = Console.ReadLine();
            Console.WriteLine("enter EMAILID");
            string Eid = Console.ReadLine();
            Console.WriteLine("press 1 to create a salried employee");
            Console.WriteLine("press 2 to create a contract employee");
            int a = int.Parse(Console.ReadLine());
            if (a == 1)
            {
                salemp e1 = new salemp();
                e1.disp();

            }
            else
            {
                conemp e2 = new conemp(id, FN, LN, Eid);
            }
        }
    }
    class baseperson
    {
        public string eid;
           public string fN;
           public int id;
           public string lN;

        }
        abstract class iprivilage
        {
            public void disp()
            {
            Console.WriteLine("Hello I am a privilage club member");
            Console.Read();
        }
        }

        class salemp : iprivilage
        {
            new void disp()
            {
                
            }
        }
        class conemp : baseperson
        {
            public conemp(int id, string fN, string lN, string eid)
            {
                this.id = id;
                this.fN = fN;
                this.lN = lN;
                this.eid = eid;
            Console.WriteLine("Employeeid="+id+ "/Name=" + fN + lN+ " and Email"+ eid);
                Console.WriteLine("Not a privilage club member");
                Console.Read();

        }

    }   
}
   

