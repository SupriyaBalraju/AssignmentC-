﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace caallback
{
    class Program
    {
        static void Main(string[] args)
        {
            delegate object MyDelegate(int i,int j, callback) 
        }
    }
}
