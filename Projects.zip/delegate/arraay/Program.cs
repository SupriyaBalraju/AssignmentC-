﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace arraay
{
    class Program
    {
        static void Main(string[] args)
        {
            char[] vowels = new char[] { 'a', 'e', 'i', 'o', 'u' };
            Console.WriteLine( " the array "+vowels[0] +vowels[1] + vowels[2] + vowels[3] + vowels[4]);
          

            int[,] matrix = new int[3, 3];
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    matrix[i, j] = i * 3 + j;
                    Console.WriteLine(" the two dimentional array" + matrix[i, j]);
                }
            }

            int[][] matrix1 = new int[3][];
            for (int i = 0; i < matrix1.Length; i++)
            {
                matrix1[i] = new int[3]; // Create inner array
                for (int j = 0; j < matrix1[i].Length; j++)
                {
                    matrix1[i][j] = i * 5 + j;
                    Console.Write( matrix1[i][j]);
                }
                Console.WriteLine();
            }

            Console.Read();

        }
    }
}
