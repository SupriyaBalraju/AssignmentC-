﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace @delegate
{
    class Program
    {
        delegate void MyDelegate(int i, int j);
        static void Main()
        {
            Console.WriteLine("calculator ");
            Console.WriteLine("press 1 for addition ");
            Console.WriteLine("press 2 for subtraction ");
            Console.WriteLine("press 3 for multiplication ");
            Console.WriteLine("press 4 for division ");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("enther the 1st no:");
            int i = int.Parse(Console.ReadLine());
            Console.WriteLine("enther the 2nd no:");
            int j = int.Parse(Console.ReadLine());
            switch (a)
            {

                case 1:
                    MyDelegate del = Sum;
                    del(i, j);
                    break;

                case 2:
                    del = sub;
                    del(i, j);
                    break;
                case 3:
                    del = mul;
                    del(i, j);
                    break;
                case 4:
                    {
                        if (j != 0)
                        {
                            del = div;
                            del(i, j);
                        }
                        else
                        {
                            Console.WriteLine("the result is infinite");
                        }
                    }
                    break;
                 
            }
            Console.Read();
        }
       
        private static void Sum(int i ,int j)
        {
            Console.WriteLine($"the sum is {i + j}");
            Console.ReadLine();
        }
        private static void sub(int i,int j)
        {
            Console.WriteLine($"the difference is {i - j}");
            Console.ReadLine();
        }
        private static void mul(int i, int j)
        {
            Console.WriteLine($"the product is {i * j}");
            Console.ReadLine();
        }
        private static void div(int i, int j)
        {
            Console.WriteLine($"the reminder is {i / j}");
            Console.ReadLine();
        }
        
    }
}
