﻿using System;
using System.Windows;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Controls;

namespace ConsoleApplication8
{
    class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            Window window = new Window();
            window.Height = 400;
            window.Width = 600;
            window.Title = "MY FIRST APP";
            window.Background = Brushes.AliceBlue;

            Color colour = new Color();
            colour.R = 255;
            colour.B = 0;
            colour.G = 0;
            colour.A = 255;

            SolidColorBrush scb = new SolidColorBrush();
            scb.Color = colour;

            Button btn = new Button();
            btn.Height = 23;
            btn.Width = 75;
            btn.Content = "CLICK";
            btn.Click += (s, e) => { MessageBox.Show("HELLO WELCOME!!"); };
           

            window.Content = btn;
            btn.Background = Brushes.Bisque;
            btn.Foreground = Brushes.BurlyWood;

            Application app = new Application();
            app.Run(window);



        }
    }
}
