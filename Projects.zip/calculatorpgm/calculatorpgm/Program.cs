﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
       
        static void Main(string[] args)
        {
            Console.WriteLine("ENTER THE CHOICE OF YOUR NUMBER TO PROCEED WITH THE CALCULATION");
            Displaymenu();
            int choice = int.Parse(Console.ReadLine());
            Console.WriteLine("ENTER THE FIRST NUMBER");
            int num1 = int.Parse(Console.ReadLine());
            Console.WriteLine("ENTER THE SECOND NUMBER");
            int num2 = int.Parse(Console.ReadLine());
            Console.Read();

            switch (choice)
            {
                case 1: Add(num1, num2); break;
                case 2: Substract(num1, num2); break;
                case 3: Multiply(num1, num2); break;
                case 4: Divide(num1, num2);break;
                    
            }
        }
        private static void Divide(int a, int b)
        {
            if (b != 0)
            {
                int result = a / b;
                Console.WriteLine("THE QUOTIENT OF TWO NUMBERS IS " + result);
                Console.Read();
            }
            else
            {
                Console.WriteLine("sorry !! change your choice of divisor");
                Console.Read();
            }
            
            
            Console.Read();
        }
                
        public static void Multiply(int a, int b)
        {
            int result = a*b;
            Console.WriteLine("THE PRODUCT OF TWO NUMBERS IS " + result);
            Console.Read();

        }

        public static void Substract(int a, int b)
        {
            int result = a - b;
            Console.WriteLine("THE DIFFERENCE OF TWO NUMBERS IS " + result);
            Console.Read();
        }

        public static void Add(int a , int b)
        {
            int result =  a + b ;
            Console.WriteLine("THE SUM OF TWO NUMBERS IS " + result);
            Console.Read();
        }
       

        public static void Displaymenu()
        {
            Console.WriteLine("1. Add");
            Console.WriteLine("2. Sub");
            Console.WriteLine("3. Multiply");
            Console.WriteLine("4. Divide");
        }
       
    }

}
       

