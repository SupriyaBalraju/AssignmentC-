﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace paramaas
{
    class Test
    {
        static int Sum(params int[] ints)
        {
            int sum = 0;
            for (int i = 0; i < ints.Length; i++)
                sum += ints[i]; // Increase sum by ints[i]
            return sum;
        }
        void foo(int x= GetInt())
        {
            foo();
        }
        static void Main()
        {
            int total = Sum(1, 2, 3, 5);
            Console.WriteLine(total); // 10
            Console.Read();
        }
    }
}
