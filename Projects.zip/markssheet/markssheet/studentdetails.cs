﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace markssheet
{
    internal class studentdetails
    {
        public void studentdeatils()
        {
            Console.WriteLine("Enter the roll no");
            int rollno = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the marks obtained in Physics");
            int markp = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the marks obtained in Chemistry");
            int markc = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the marks obtained in Mathematics");
            int markm = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the marks obtained in Biology");
            int markb = int.Parse(Console.ReadLine());
            Console.Read();
        }
    }
 }
