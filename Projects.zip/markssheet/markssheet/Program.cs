﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace markssheet
{
    class Program
    {
        static int a= int.Parse(Console.ReadLine());
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the no of students of a class, whose marks have to be entered");
         
            Program.studentdetails(a);
        }    

        public static void studentdetails(int a)
        {
            for (int i = 0; i <= a; i++)
            {
                Console.WriteLine("Enter the roll no");
                int[] rollno = new int[i];
                rollno[i] = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter the marks obtained in Physics");
                double[] markp = new double[i];
                markp[i] = double.Parse(Console.ReadLine());
                Console.WriteLine("Enter the marks obtained in Chemistry");
                double[] markc = new double[i];
                markc[i] = double.Parse(Console.ReadLine());
                Console.WriteLine("Enter the marks obtained in Mathematics");
                double[] markm = new double[i];
                markm[i] = double.Parse(Console.ReadLine());
                Console.WriteLine("Enter the marks obtained in Biology");
                double[] markb = new double[i];
                markb[i] = double.Parse(Console.ReadLine());
                Console.Read();
            }
        }


    }
        
    }

