﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    public class Person
    {
        public string Name { get; set; }
        public int ID { get; private set;}

    }
    class Program
    {
        static void Main(string[] args)
        {
            Person p = new Person();
            p.Name = "Supriya";
            Console.WriteLine("Person Name = {0} ID= {1}", p.Name, p.ID);
            Console.WriteLine("Person Name = {0} ID= {1}", p.Name, p.ID);
            Console.ReadKey();
           
        }
    }

}    




  