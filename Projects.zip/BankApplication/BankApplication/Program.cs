﻿using BankApplication;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApplication
{
    class Program
    {
        public static List<SavingsAccount> savac = new List<SavingsAccount>
            {
                new SavingsAccount ("Supriya.B",6611,5023230233016099,10000 ),
                new SavingsAccount ("Nikitha.S",  1208,  5023230212016008, 20000 ),
                new SavingsAccount ("Prithvi.K.M",  8080, 5023230208016009, 30000)
            };

        public static List<CurrentAccount> curac = new List<CurrentAccount>
            {
                new CurrentAccount ("Supriya.B", 6611 , 6023230233016099, 20000),
                new CurrentAccount ("Nikitha.S", 1208 , 6023230212016008, 40000),
                new CurrentAccount ("Prithvi.K.M", 8080 , 6023230208016009, 30000)
            };


        static void Main(string[] args)
        {
            string confirm="";

            Console.ForegroundColor = ConsoleColor.DarkMagenta;
            Console.WriteLine("**************************Welcome to Banking Services**************************");
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("                                 ");
            Console.WriteLine("If you already have a account Press 1 or Press 2 to create new account ");
            int a = int.Parse(Console.ReadLine());
            do
            {
                if (a == 1)
                {
                    Console.WriteLine("Please select your Account type");
                    Console.WriteLine("Press 1 for Savings Account");
                    Console.WriteLine("Press 2 for Current Account");
                    int type = int.Parse(Console.ReadLine());
                    if (type == 1)
                    {
                        Console.WriteLine("Enter your Name");
                        string name = Console.ReadLine();
                        Console.WriteLine("Enter your 4digit PIN");
                        int pin = int.Parse(Console.ReadLine());
                        SavingsAccount s1 = SavingsAccount.validation(pin, name);
                        if (s1 != null)
                        {
                            Console.WriteLine("PRESS 1:Check Balance\n 2:Withdraw Amount \n 3:Deposit Amount \n 4:Close Account \n 5:Edit Account");
                            int press = int.Parse(Console.ReadLine());
                            switch (press)
                            {
                                case 1:
                                    s1.Check_Balance();
                                    break;

                                case 2:
                                    s1.Withdrawal();
                                    break;

                                case 3:
                                    s1.Deposit();
                                    break;

                                case 4:
                                    s1.CloseAccount();
                                    break;

                                case 5:
                                    s1.EditAccount();
                                    break;

                                default:
                                    Console.WriteLine("If you already have a account Press 1 or Press 2 to create new account ");
                                    a = int.Parse(Console.ReadLine());
                                    break;

                            }
                        }
                        //else
                        //{
                        //    Console.WriteLine("If you already have a account Press 1 or Press 2 to create new account ");
                        //    a = int.Parse(Console.ReadLine());

                        //}
                    }


            

                else if (type == 2)
                {
                    Console.WriteLine("Enter your Name");
                    string name = Console.ReadLine();
                    Console.WriteLine("Enter your 4digit PIN");
                    int pin = int.Parse(Console.ReadLine());
                    CurrentAccount c1 = CurrentAccount.validation(pin, name);
                    if (c1 != null)
                    {
                        Console.WriteLine("PRESS 1:Check Balance\n 2:Withdraw Amount \n 3:Deposit Amount \n 4:Close Account \n 5:Edit Account");
                        int press = int.Parse(Console.ReadLine());
                        switch (press)
                        {
                            case 1:
                                c1.Check_Balance();
                                break;

                            case 2:
                                c1.Withdrawal();
                                break;

                            case 3:
                                c1.Deposit();
                                break;

                            case 4:
                                c1.CloseAccount();
                                break;

                            case 5:
                                c1.EditAccount();
                                break;
                        }

                    }

                }

            }
                else if (a == 2)
                {
                    Console.WriteLine("Choose your choice of account ; Press 1 for creating a Savings account and Press 2 for creating a Current account ");
                    int b = int.Parse(Console.ReadLine());
                    if (b == 1)
                    {
                        SavingsAccount sa = new SavingsAccount();
                        sa.OpenAccount();
                        if (sa.balance > 1000)
                        {
                            savac.Add(sa);
                        }


                    }
                    else if (b == 2)
                    {
                        CurrentAccount ca = new CurrentAccount();
                        ca.OpenAccount();
                    }

                }
                    Console.WriteLine("Enter y to continue");
                    confirm = Console.ReadLine().ToUpper();

                   // Console.Read();

              


            } while (confirm == "Y");
            Console.ReadLine();
        }
    }
}
