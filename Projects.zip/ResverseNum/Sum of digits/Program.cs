﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sum_of_digits
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter an integer to which you want to find sum of digits");
            int num = int.Parse(Console.ReadLine());
            int Num = num;
            int sum = 0;
            while(num!=0)
            {
                int r = num % 10;
                num = num / 10;
                sum = sum + r;

            }
            Console.WriteLine("The sum of digits of a no " + Num + " is " + sum);
            Console.Read();

        }
    }
}
