﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    enum menuoptions {add=1, sub=2, div=3, multiply=4};
    class Program
    {
        static void Main(string[] args)
        {
            //1.Display menu
            Displaymenu();

            //2.User's choice
            Console.WriteLine("enter your choice");
            int choice = getInt("choice?");
            
            //3.get the input

            int num1 = getInt("enter number 1");

            int num2 = getInt("enter number 2");

            //4.apply operations
            int res = 0;
            Console.WriteLine(res);
            switch ((menuoptions)choice)
            {
                case menuoptions.add: res = num1 + num2;
                    break;
                case menuoptions.sub: res = num1 - num2;
                    break;
                case menuoptions.div: res = num1 / num2;
                    break;
                case menuoptions.multiply: res = num1 * num2;
                    break;
            }
            Console.Read();
        }
             

        private static int getInt(string msg)
        {
            Console.WriteLine(msg);
            int val = 0;
            {
                while(true)
                {
                    if (int.TryParse(Console.ReadLine(), out val))
                        break;
                }
            }
            return val;
        }

        private static void Displaymenu()
        {
            string[] menuchoices = {
                "1.ADD",
                "2.SUB",
                "3.DIVISION",
                "4.MULTIPLICATION"
            };

            foreach(string item in menuchoices)
            {
                Console.WriteLine(item);
            }
            // Console.WriteLine("1.ADD");
            //Console.WriteLine("1.SUB");

        }
    }
}
