﻿namespace VehicleDealer
{
    public class Vehicles
    {
        string name;
        int id;
        int noOfModels;
    }
}