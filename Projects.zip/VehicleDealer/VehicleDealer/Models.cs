﻿using System;

namespace VehicleDealer
{
    public class Models:Vehicles
    {
       
        public int id;
        public string model;
        public double price;
        public Boolean instock;
        public static void StationWagon()
        {
          
        }
        public static void Van()
        {
            
        }

        public static void Car()
        {
            public void add_model()
            {

            }
            Console.WriteLine("");
        }
    }
}}