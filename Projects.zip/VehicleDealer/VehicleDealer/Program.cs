﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VehicleDealer
{
    class Program
    {
        public static List<Models> car = new List<Models>
        {
            new Models {id= 1,model="Swift",price=650000,instock=true },
            new Models {id= 2,model="Civic",price=1300000,instock=true },
            new Models {id= 3,model="Accord",price=6500000,instock=true },
            new Models {id= 4,model="Audi A6",price=10000000,instock=true },
            new Models {id= 5,model="Jaguar",price=150000000,instock=true },
        };
        public static List<Models> Van = new List<Models>
        {
            new Models {id= 1,model="Ashokleyland45",price=6500000,instock=true },
            new Models {id= 2,model="PiaggioApe",price=1300000,instock=true },
            new Models {id= 3,model="Mahindra1",price=6500000,instock=true },
            new Models {id= 4,model="Goodsvan23",price=10000000,instock=true },
            new Models {id= 5,model="Mercedes123",price=150000000,instock=true },
        };
        public static List<Models> Stationwagon = new List<Models>
        {
            new Models {id= 1,model="Ashokleyland45",price=6500000,instock=true },
            new Models {id= 2,model="PiaggioApe123",price=1300000,instock=true },
            new Models {id= 3,model="Mahindra1345",price=6500000,instock=true },
            new Models {id= 4,model="Goodsvan236",price=10000000,instock=true },
            new Models {id= 5,model="Mercedes1236",price=150000000,instock=true },
        };
        static void Main(string[] args)
        {
           
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("*******************Welcome to Mahindra Dealers!!!!*******************");
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("Select the type of 4 wheeler from the below listed categories \n 1.CAR \n 2.VAN \n 3.STATION WAGON");
            int type = int.Parse(Console.ReadLine());
            if (type == 1)
            {
                Models.Car();
            }
            else if (type == 2)
            {
                Models.Van();
            }
            else if (type == 3)
            {
                Models.StationWagon();
            }
            else
            {
                Console.WriteLine("Select the type of 4 wheeler from the below listed categories \n 1.CAR \n 2.VAN \n 3.STATION WAGON");
                type = int.Parse(Console.ReadLine());
            }
         


            Console.Read();






        }

       

       
    }
    
}
